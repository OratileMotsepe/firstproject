/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.application;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class Application {
    
    public static void main(String[] args) { 
        Scanner input = new Scanner(System.in); 
        System.out.print("Log in or Create new account: "); 
        
        String account = input.nextLine(); 
        System.out.print("Enter First name: "); 
        
        String firstName = input.nextLine(); 
        System.out.print("Enter Last name: "); 
        
        String lastName = input.nextLine(); 
        System.out.print("Enter Username: "); 
        
        String username = input.nextLine(); 
        System.out.print("Enter Password: "); 
        
        String password = input.nextLine(); 
        System.out.print("Enter a valid South African phone number: "); 
        
        String phoneNumber = input.nextLine();   
 
        User user = new User(firstName, lastName, username, password, phoneNumber); 
        
        System.out.println("\nAccount status:"); 
        
        Login.checkUserName(user.username); 
        Login.checkPasswordComplexity(user.password); 
        Login.checkCellPhoneNumber(user.phoneNumber);
        
        String registrationMessage = Login.registerUser(username, password); 
        System.out.println(registrationMessage); 
        
        System.out.println("\nLogin to Account:"); 
        
        System.out.print("Enter Username: "); 
        String loginUsername = input.nextLine(); 
        
        System.out.print("Enter Password: "); 
        String loginPassword = input.nextLine(); 
        
        String accountMessage = Login.returnLoginStatus(loginUsername, loginPassword, user, user.firstName, user.lastName); 
        System.out.println(accountMessage); 
        
        Login.loginUser(user.username, user.password, user, user.lastName, user.firstName); 
        
        input.close();   
     
    }   
}  

class User { String firstName; String lastName; String username; String password; String phoneNumber;
    public User(String firstName, String lastName, String username, String password, String phoneNumber) { 
        
        this.firstName = firstName; 
        this.lastName = lastName; 
        this.username = username; 
        this.password = password; 
        this.phoneNumber = phoneNumber; 
 
    }   
}  

class Login { 
    public static boolean checkUserName(String username) { 
        if (!username.contains("_")) { 
            return false; 
        } else if (username.length() > 5) { 
            return false; 
        } else { 
            return true; 
    } 
}   
 
public static boolean checkPasswordComplexity(String password) { 
    if (!password.matches(".*[A-Z].*")) { 
        return false; 
    } else if (password.length() < 8) {   
        return false; 
    } else if (!password.matches(".*\\d.*")) {   
        return false; 
    } else if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*")) {   
        return false; 
    } else {   
        return true; 
    }   
}   
 
public static boolean checkCellPhoneNumber(String phoneNumber) {   
    if (!phoneNumber.matches("^\\+27\\d{9}$")) {   
        System.out.println("Cell phone number incorrectly formatted or does not contain international code"); 
        return false; 
    } else {   
        System.out.println("Cell phone number successfully captured");
        return true; 
    }   
}  
 
public static String registerUser(String username, String password) { 
    if (!checkUserName(username)) {
        return "Username is not correctly formatted; please ensure your username contains an underscore and is no more than five characters in length.";
    } else if (!checkPasswordComplexity(password)) {
        return "Password is not correctly formatted; please ensure your password contains at least eight characters, a capital letter, a number, and a special character.";
    } else {
        return "Username and password successfully captured.";
    }
} 

public static boolean loginUser(String loginUsername, String loginPassword, User user, String firstName, String lastName) {
    if (loginUsername.equals(user.username) && loginPassword.equals(user.password)) { 
        return true; 
    } else {  
        return false;  
    }  
} 
 
public static String returnLoginStatus(String loginUsername, String loginPassword, User user, String firstName, String lastName) { 
    if (loginUser(loginUsername, loginPassword, user, user.firstName, user.lastName)) { 
        return "Welcome" + " " + user.firstName + " " + user.lastName + ", it is great to see you."; 
    } else {  
        return "Username or password incorrect, please try again.";
    } 
}
    
}
