/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package TestMethods;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class TestAccount {
    
    class LoginTest {
        
    // checkUserName tests
    
    @Test
    void testUsernameValid() {
        assertTrue(Login.checkUserName("Kyl_1"));
    }
    
    @Test
    void testUsernameLength() {
        assertFalse(Login.checkUserName("kyle!!!!!!!"));
    }

    // checkPasswordComplexity tests
   
    @Test
    void testPasswordUppercaseOmitted() {
        assertFalse(Login.checkPasswordComplexity("password"));
    }

    @Test
    void testPasswordValid() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99"));
    }

    // =========================
    // checkCellPhoneNumber tests
    // =========================

    @Test
    void testIncorrectPhoneNumber() {
        assertFalse(Login.checkCellPhoneNumber("0812345678"));
    }

    @Test
    void testCorrectPhoneNumber() {
        assertTrue(Login.checkCellPhoneNumber("+27812345678"));
    }

    // registerUser tests

    @Test
    void testRegisterUserInvalidUsername() {
        String result = Login.registerUser("johnny", "Password1!");
        assertEquals(
            "Username is not correctly formatted; please ensure your username contains an underscore and is no more than five characters in length.",
            result
        );
    }

    @Test
    void testRegisterUserInvalidPassword() {
        String result = Login.registerUser("jo_hn", "password");
        assertEquals(
            "Password is not correctly formatted; please ensure your password contains at least eight characters, a capital letter, a number, and a special character.",
            result
        );
    }

    @Test
    void testRegisterUserSuccess() {
        String result = Login.registerUser("jo_hn", "Password1!");
        assertEquals("Username and password successfully captured.", result);
    }

    // =========================
    // loginUser + returnLoginStatus tests
    // =========================

    @Test
    void testLoginUserSuccess() {
        User user = new User();
        user.username = "kyl_1";
        user.password = "Ch&&sec@ke99";
        user.firstName = "Kyle";
        user.lastName = "Bruce";

        assertTrue(Login.loginUser("Kyle", "Ch&&sec@ke99", user, "Kyle", "Bruce"));
    }

    @Test
    void testLoginUserFail() {
        User user = new User();
        user.username = "kyl_1";
        user.password = "Ch&&sec@ke99";
        user.firstName = "Kyle";
        user.lastName = "Bruce";

        assertFalse(Login.loginUser("wrong", "wrong", user, "Kyle", "Bruce"));
    }

    @Test
    void testReturnLoginStatusPass() {
        User user = new User();
        user.username = "kyl_1";
        user.password = "Ch&&sec@ke99";
        user.firstName = "Kyle";
        user.lastName = "Bruce";

        String result = Login.returnLoginStatus("kyl_1", "Ch&&sec@ke99", user, "Kyle", "Bruce");

        assertEquals("Welcome Kyle Bruce, it is great to see you.", result);
    }

    @Test
    void testReturnLoginStatusFail() {
        User user = new User();
        user.username = "kyl_1";
        user.password = "Ch&&sec@ke99";
        user.firstName = "Kyle";
        user.lastName = "Bruce";

        String result = Login.returnLoginStatus("wrong", "wrong", user, "John", "Doe");

        assertEquals("Username or password incorrect, please try again.", result);
    }
}
    
}
